# Reporte de Pruebas - Punto 4

## Casos de Exito
1. 48 18: Resultado MCD = 6.
2. Numeros grandes: Soporta long long para evitar desbordamientos comunes.

## Intentos de Romper el Programa
1. Entrada no numerica (abc 123): El uso de 'strtoll' con punteros de control detecta que no es un numero y evita el cierre inesperado.
2. Desbordamiento: Se valida el rango para evitar errores de memoria.

## Evidencia Visual
![alt text](image.png)