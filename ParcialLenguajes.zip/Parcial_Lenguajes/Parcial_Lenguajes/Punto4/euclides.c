#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

long long mcd(long long a, long long b) {
    while (b) { a %= b; long long t = a; a = b; b = t; }
    return a;
}

int main() {
    FILE *f = fopen("entradas.txt", "r");
    if (!f) { printf("No existe entradas.txt\n"); return 1; }
    
    char s1[100], s2[100];
    printf("%-20s %-20s | %s\n", "NUM 1", "NUM 2", "RESULTADO");
    printf("------------------------------------------------------------\n");
    
    while (fscanf(f, "%s %s", s1, s2) != EOF) {
        char *p1, *p2;
        errno = 0;
        long long n1 = strtoll(s1, &p1, 10);
        long long n2 = strtoll(s2, &p2, 10);

        if (*p1 != '\0' || *p2 != '\0' || errno == ERANGE) {
            printf("%-20s %-20s | ERROR: Entrada invalida\n", s1, s2);
        } else {
            printf("%-20lld %-20lld | MCD: %lld\n", n1, n2, mcd(abs(n1), abs(n2)));
        }
    }
    fclose(f);
    return 0;
}
