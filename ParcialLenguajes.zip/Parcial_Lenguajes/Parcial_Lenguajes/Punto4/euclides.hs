import System.Environment (getArgs)
import Text.Read (readMaybe)

-- Implementación declarativa robusta
gcdRecursive :: Integer -> Integer -> Integer
gcdRecursive a 0 = abs a
gcdRecursive a b = gcdRecursive b (a `mod` b)

main :: IO ()
main = do
    args <- getArgs
    case args of
        [arg1, arg2] -> do
            let n1 = readMaybe arg1 :: Maybe Integer
            let n2 = readMaybe arg2 :: Maybe Integer
            case (n1, n2) of
                (Just x, Just y) -> putStrLn $ "MCD(" ++ show x ++ ", " ++ show y ++ ") = " ++ show (gcdRecursive x y)
                _                -> putStrLn "Error: Las entradas deben ser números enteros."
        _ -> putStrLn "Error: Se requieren exactamente dos argumentos."
