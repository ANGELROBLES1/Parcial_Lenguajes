# Punto 4: Algoritmo de Euclides (MCD)

Calculo del Maximo Comun Divisor utilizando recursividad y manejo de tipos de datos extensos.

## Especificacion Tecnica
- Lenguaje: C (GCC)
- Entrada: archivo 'entradas.txt' (Pares de numeros)

## Instrucciones de Ejecucion
1. Compilar: gcc euclides.c -o euclides_c
2. Ejecutar: ./euclides_c