# Reporte de Pruebas - Punto 5

## Casos de Exito
1. calc(1, 10): Resultado aproximado a la constante e.
2. calc(-1, 5): Manejo correcto de exponentes negativos.

## Intentos de Romper el Programa
1. n > 170 (Overflow): El programa detecta que el factorial superara el limite de Double y lanza una advertencia en lugar de imprimir "Infinity".
2. Error de sintaxis (abc): El Lexer de ANTLR identifica los tokens invalidos y el Main continua con la siguiente linea sin colapsar.

## Evidencia Visual
![alt text](image.png)