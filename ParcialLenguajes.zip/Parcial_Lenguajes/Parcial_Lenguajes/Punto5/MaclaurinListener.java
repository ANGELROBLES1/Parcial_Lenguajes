// Generated from Maclaurin.g4 by ANTLR 4.13.2

import java.lang.Math;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link MaclaurinParser}.
 */
public interface MaclaurinListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link MaclaurinParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(MaclaurinParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link MaclaurinParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(MaclaurinParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link MaclaurinParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterStat(MaclaurinParser.StatContext ctx);
	/**
	 * Exit a parse tree produced by {@link MaclaurinParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitStat(MaclaurinParser.StatContext ctx);
	/**
	 * Enter a parse tree produced by {@link MaclaurinParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(MaclaurinParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link MaclaurinParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(MaclaurinParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link MaclaurinParser#number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(MaclaurinParser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link MaclaurinParser#number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(MaclaurinParser.NumberContext ctx);
}