# Punto 5: Calculadora Maclaurin con ANTLR4

Parser y Lexer para calcular aproximaciones de e^x leyendo comandos calc(x, n).

## Especificacion Tecnica
- Lenguaje: Java / ANTLR4
- Entrada: archivo 'entradas.txt'

## Instrucciones de Ejecucion
1. Generar parser: antlr4 Maclaurin.g4
2. Compilar: javac Maclaurin*.java Main.java
3. Ejecutar: java Main