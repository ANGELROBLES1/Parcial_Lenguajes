import org.antlr.v4.runtime.*;
import java.io.FileInputStream;

public class Main {
    public static void main(String[] args) {
        try {
            FileInputStream fis = new FileInputStream("entradas.txt");
            MaclaurinLexer lexer = new MaclaurinLexer(CharStreams.fromStream(fis));
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            MaclaurinParser parser = new MaclaurinParser(tokens);
            parser.prog();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
