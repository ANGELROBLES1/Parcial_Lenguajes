grammar Maclaurin;

@header {
import java.lang.Math;
}

@members {
    public double factorial(int n) {
        double f = 1;
        for (int i = 1; i <= n; i++) f *= i;
        return f;
    }
}

prog: stat+ ;

stat: expr (NEWLINE | EOF)
    | NEWLINE 
    ;

expr: 'calc' '(' xVal=number ',' nVal=number ')' {
    double x = Double.parseDouble($xVal.text);
    int n = Integer.parseInt($nVal.text);
    
    if (n > 170) {
        System.out.println("calc(" + x + "," + n + ") -> Error: n muy grande (Overflow)");
    } else {
        double result = 0;
        for (int k = 0; k < n; k++) {
            result += Math.pow(x, k) / factorial(k);
        }
        System.out.println("calc(" + x + "," + n + ") -> Resultado: " + result);
    }
} ;

number: INT | FLOAT | MINUS INT | MINUS FLOAT;

INT: [0-9]+ ;
FLOAT: [0-9]+ '.' [0-9]+ ;
MINUS: '-' ;
NEWLINE: '\r'? '\n' ;
WS: [ \t]+ -> skip ;
