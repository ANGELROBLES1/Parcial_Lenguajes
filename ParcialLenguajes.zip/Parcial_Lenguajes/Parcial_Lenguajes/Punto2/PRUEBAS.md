# Reporte de Pruebas - Punto 2

## Casos de Exito
1. MiVariable: Reconocido como identificador valido.
2. A: Caso minimo aceptado (una sola letra).

## Intentos de Romper el Programa
1. Numero inicial (123id): El programa arroja "No inicia con letra" al fallar en q0.
2. Caracteres especiales (var_!): El bucle se rompe al detectar '!' y reporta el caracter invalido.

## Evidencia Visual
![alt text](image.png)