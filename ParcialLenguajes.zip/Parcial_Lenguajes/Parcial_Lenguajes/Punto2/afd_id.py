import os

def afd_id(cadena):
    cadena = cadena.strip()
    if not cadena: return False, "Vacio"
    estado = "q0"
    for char in cadena:
        if estado == "q0":
            if char.isalpha(): estado = "q1"
            else: return False, "No inicia con letra"
        elif estado == "q1":
            if char.isalnum(): estado = "q1"
            else: return False, f"Caracter '{char}' invalido"
    return (True, "ACEPTE") if estado == "q1" else (False, "Error")

if __name__ == "__main__":
    if os.path.exists("entradas.txt"):
        with open("entradas.txt", "r") as f:
            for linea in f:
                val, msg = afd_id(linea)
                print(f"{linea.strip():<15} | {msg}")
