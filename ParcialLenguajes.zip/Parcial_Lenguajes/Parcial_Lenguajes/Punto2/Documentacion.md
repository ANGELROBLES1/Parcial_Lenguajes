# Punto 2: AFD para Identificadores

Implementacion de un AFD para reconocer nombres de variables validos segun la jerarquia de lenguajes regulares.

## Especificacion Tecnica
- Lenguaje: Python 
- Expresion Regular: [A-Za-z][A-Za-z0-9]*
- Entrada: archivo 'entradas.txt'

## Instrucciones de Ejecucion
1. Ubicarse en la carpeta: cd Punto2
2. Ejecutar: python3 afd_id.py