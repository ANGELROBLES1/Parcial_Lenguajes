%{
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void yyerror(const char *s);
extern int yylex();
extern FILE *yyin;

/* Implementacion de Newton-Raphson */
double calcular_raiz(double a) {
    if (a < 0) {
        printf("Error matematico: No se puede calcular raiz de numero negativo (%.2f)\n", a);
        return -1;
    }
    if (a == 0) return 0;

    double x = a; // Aproximacion inicial
    double tolerancia = 1e-10;
    double x_nuevo;

    for (int i = 0; i < 100; i++) {
        x_nuevo = 0.5 * (x + a / x);
        if (fabs(x_nuevo - x) < tolerancia) {
            return x_nuevo;
        }
        x = x_nuevo;
    }
    return x;
}
%}

%union {
    double fval;
}

%token <fval> NUM
%token SQRT L_PAREN R_PAREN
%type <fval> exp

%%

input:
    | input line
    ;

line:
    exp { /* Fin de linea */ }
    ;

exp:
    SQRT L_PAREN NUM R_PAREN {
        double res = calcular_raiz($3);
        if (res != -1) {
            printf("sqrt(%.2f) = %.10f\n", $3, res);
        }
    }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error de sintaxis: %s\n", s);
}

int main() {
    FILE *f = fopen("entradas.txt", "r");
    if (!f) {
        perror("Error al abrir entradas.txt");
        return 1;
    }
    yyin = f;
    do {
        yyparse();
    } while (!feof(yyin));
    fclose(f);
    return 0;
}
