# Reporte de Pruebas - Punto 3 (Newton-Raphson)

## Casos de Exito
1. Entrada `sqrt(25)`: El programa aplica la fórmula iterativa y converge a 5.0000000000.
2. Entrada `sqrt(2)`: Se obtiene 1.4142135624 con una tolerancia de 1e-10.

## Manejo de Errores (Pruebas de Fallo)
1. **Raiz Negativa:** Ante `sqrt(-9)`, el programa detecta `a < 0` y lanza un mensaje de "Error matematico" sin colapsar.
2. **Error Lexico:** Ante `sqrt(abc)`, Flex reporta que los caracteres no son reconocidos como números.
3. **Error de Sintaxis:** Si se olvida un paréntesis, Bison reporta el error sintáctico específico.

## Conclusion
La implementacion es robusta ya que separa la captura de datos (Flex), la validacion de estructura (Bison) y la logica de calculo (C), asegurando precision numerica y estabilidad.

