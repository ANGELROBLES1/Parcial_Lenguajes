import os

def afd_ajedrez(cadena):
    cadena = cadena.strip()
    if not cadena: return False, "Linea vacia"
    estado, i, n = "q0", 0, len(cadena)
    while i < n:
        char = cadena[i]
        if estado == "q0":
            if char.isalpha(): estado = "q1"
            else: return False, f"Fallo en q0: '{char}' no es pieza"
        elif estado == "q1":
            if char.isalpha(): estado = "q1"
            elif char == "-":
                if i+1 < n and cadena[i+1] == ">": estado, i = "q3", i + 1
                else: return False, "Fallo en q1: '-' sin '>'"
            elif char.upper() == "X": estado = "q3"
            elif char == " ": estado = "q2"
            else: return False, f"Fallo en q1: '{char}' invalido"
        elif estado == "q2":
            if char == "-":
                if i+1 < n and cadena[i+1] == ">": estado, i = "q3", i + 1
                else: return False, "Fallo en q2: '-' incompleto"
            elif char.upper() == "X": estado = "q3"
            elif char == " ": pass
            else: return False, f"Fallo en q2: esperado accion, recibido '{char}'"
        elif estado == "q3":
            if char.isalpha(): estado = "q4"
            elif char == " ": pass
            else: return False, f"Fallo en q3: destino debe iniciar con letra"
        elif estado == "q4":
            if char.isalnum(): estado = "q4"
            else: return False, f"Fallo en q4: caracter '{char}' prohibido"
        i += 1
    return (True, "ACEPTE") if estado == "q4" else (False, "Cadena incompleta")

if __name__ == "__main__":
    if os.path.exists("entradas.txt"):
        print(f"{'CADENA':<15} | {'RESULTADO':<10} | {'DETALLE'}")
        print("-" * 50)
        with open("entradas.txt", "r") as f:
            for linea in f:
                val, msg = afd_ajedrez(linea)
                print(f"{linea.strip():<15} | {'OK' if val else 'ERROR':<10} | {msg}")
