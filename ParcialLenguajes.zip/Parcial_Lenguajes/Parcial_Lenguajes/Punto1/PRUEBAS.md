# Reporte de Pruebas - Punto 1

## Casos de Exito
1. p->k4: El programa transita de q0 a q4 correctamente.
2. kbp X qn: Piezas compuestas son aceptadas por la clausura +.

## Intentos de Romper el Programa
1. Accion incompleta (p-k4): El programa detecta que falta el caracter '>' y arroja error en q1.
2. Inicio invalido (1->k4): El AFD rechaza la cadena en el estado q0 al no recibir una letra.
3. Simbolos extra (p->k4!): Se detecta caracter prohibido en el estado de destino q4.

## Evidencia Visual
![alt text](image.png)