# Punto 1: AFD para Movimientos de Ajedrez

Este programa implementa un Automata Finito Determinista que procesa movimientos de ajedrez desde un archivo de texto.

## Especificacion Tecnica
- Lenguaje: Python 
- Expresion Regular: ([a-z]+)(->|X)([a-z]+[0-9]*)
- Entrada: archivo 'entradas.txt'

## Instrucciones de Ejecucion
1. Ubicarse en la carpeta: cd Punto1
2. Ejecutar: python3 afd_ajedrez.py