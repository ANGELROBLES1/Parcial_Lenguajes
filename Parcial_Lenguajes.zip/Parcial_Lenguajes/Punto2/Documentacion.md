# Autómata Finito Determinista (AFD) en Python

Este directorio contiene la implementación de un AFD para validar identificadores basados en la expresión regular: [A-Za-z][A-Za-z0-9]*

## Especificación del Autómata

El autómata se define mediante los siguientes elementos:

1. Alfabeto: Letras (mayúsculas y minúsculas) y dígitos del 0 al 9.
2. Estados:
   - q0: Estado inicial.
   - q1: Estado de aceptación.
   - q_error: Estado de rechazo (trampa).

### Lógica de Transiciones

- Si el autómata está en q0 y recibe una letra, pasa a q1.
- Si el autómata está en q0 y recibe cualquier otro carácter, pasa a q_error.
- Si el autómata está en q1 y recibe una letra o un número, permanece en q1.
- Si el autómata está en q1 y recibe un carácter especial o símbolo, pasa a q_error.
- Si el autómata está en q_error, cualquier entrada adicional lo mantiene en q_error.

## Código de Implementación

A continuación se presenta la lógica utilizada en el archivo afd_id.py para procesar las cadenas:

def afd_id_validator(cadena):
    estado = "q0"
    for char in cadena:
        if estado == "q0":
            if char.isalpha():
                estado = "q1"
            else:
                estado = "q_error"
        elif estado == "q1":
            if char.isalnum():
                estado = "q1"
            else:
                estado = "q_error"
        
        if estado == "q_error":
            break
            
    return estado == "q1"

## Pruebas Realizadas

Se definieron 5 casos de prueba para verificar el comportamiento del sistema:

1. Cadena: 'MiVariable'
Resultado: ACEPTE
Explicación: Inicia con letra y continúa con caracteres alfanuméricos. El estado final es q1.

2. Cadena: 'id123'
Resultado: ACEPTE
Explicación: El primer carácter es una letra y los dígitos posteriores son permitidos en q1.

3. Cadena: 'A'
Resultado: ACEPTE
Explicación: Cumple con el requisito mínimo de iniciar con una letra.

4. Cadena: '123id'
Resultado: NO ACEPTE
Explicación: El primer carácter es un dígito, lo que provoca una transición inmediata de q0 a q_error.

5. Cadena: 'var_nombre!'
Resultado: NO ACEPTE
Explicación: Contiene caracteres especiales (_) que no forman parte del alfabeto permitido, enviando el proceso a q_error.

## Conclusión

La implementación cumple con los requisitos de un lenguaje regular. El programa garantiza que solo las cadenas que inicien con caracteres alfabéticos y contengan únicamente caracteres alfanuméricos sean aceptadas por el sistema.
