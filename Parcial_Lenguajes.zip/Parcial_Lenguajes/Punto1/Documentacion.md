# Punto 1: AFD para Movimientos de Ajedrez

Este directorio contiene la implementacion de un Automata Finito Determinista (AFD) que procesa movimientos de ajedrez desde un archivo de texto plano.

## Especificacion
El lenguaje acepta cadenas bajo la expresion regular: ([a-z]+)(->|X)([a-z]+[0-9]*)

## Estructura del Proyecto
- afd_ajedrez.py: Script de Python con la logica del automata.
- entradas.txt: Archivo que contiene los casos de prueba (exito y error).

## Instrucciones de Ejecucion
1. Asegurese de tener el archivo entradas.txt en la misma carpeta que el script.
2. Ejecute el comando:
   python3 afd_ajedrez.py

## Analisis de Pruebas de Error

El programa ha sido diseñado para capturar y reportar los siguientes errores comunes:

1. Error de Inicio: Cadenas que comienzan con numeros o simbolos (Ej: 1->k4).
2. Error de Accion Incompleta: Uso de '-' sin el '>' o falta de operador entre pieza y casilla (Ej: p-k4, p k4).
3. Error de Destino Invalido: Cadenas que terminan antes de definir la casilla o usan simbolos prohibidos (Ej: p->, p->k4!).

## Resultados de la Ejecucion

A continuacion se detallan los resultados obtenidos al procesar el archivo de entradas:

- p->k4: OK (ACEPTE)
- kbp X qn: OK (ACEPTE)
- p->k: OK (ACEPTE)
- 1->k4: ERROR (Error en q0: '1' no es una pieza valida)
- p->: ERROR (Error: Cadena incompleta)
- p k4: ERROR (Error en q2: Se esperaba '->' o 'X')
- p-k4: ERROR (Error en q1: Simbolo '-' incompleto)
- p->k4!: ERROR (Error en q4: Caracter especial '!' no permitido)

## Conclusion
La implementacion mediante lectura de archivos permite procesar lotes de movimientos de forma eficiente. El sistema de estados garantiza que solo las secuencias que cumplan estrictamente con el formato Pieza-Accion-Casilla lleguen al estado de aceptacion.
