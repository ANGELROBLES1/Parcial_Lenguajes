# 🧮 Calculadora de Serie de Maclaurin con ANTLR4

Este proyecto implementa un reconocedor de lenguaje y una calculadora matemática para aproximar el valor de $e^x$ utilizando los primeros $n$ términos de la serie de Maclaurin.

## Explicación de la Solución

### 1. Fundamento Matemático
La serie de Maclaurin para la función exponencial se define como:
$$e^x = \sum_{i=0}^{n-1} \frac{x^i}{i!} = 1 + x + \frac{x^2}{2!} + \frac{x^3}{3!} + \dots + \frac{x^{n-1}}{(n-1)!}$$

El programa toma dos parámetros:
- **x**: El exponente al que se eleva la constante $e$.
- **n**: La cantidad de términos de la serie para la aproximación (precisión).

### 2. Arquitectura del Programa
La solución utiliza **ANTLR4** para procesar la entrada del usuario mediante tres fases:

1.  **Analizador Léxico (Lexer):** Tokeniza la entrada. Reconoce palabras clave (`calc`), operadores de agrupación (`(`, `)`), separadores (`,`) y valores numéricos (incluyendo negativos y decimales).
2.  **Analizador Sintáctico (Parser):** Valida que la estructura del comando sea correcta siguiendo la regla: `calc(valor, valor)`.
3.  **Acciones Semánticas (Java):** Una vez validada la estructura, se ejecuta código Java embebido que realiza el cálculo iterativo de la sumatoria y gestiona el factorial.

### 3. Manejo de Errores y Robustez
Para garantizar que el programa sea propenso a errores controlados y no a fallos críticos, se implementaron:

| Escenario de Error | Estrategia de Mitigación |
| :--- | :--- |
| **Entrada No Numérica** | El Lexer rechaza caracteres no permitidos (ej. `xyz`) disparando un `token recognition error`. |
| **Estructura Incorrecta** | El Parser detecta la falta de comas o paréntesis y detiene la ejecución. |
| **N Negativo o Cero** | Validación lógica en Java que impide procesar series con términos inválidos. |
| **Desbordamiento (Overflow)** | Límite fijado en $n=170$ para evitar que el factorial exceda la capacidad del tipo `double`. |

---

## 🛠️ Instrucciones de Uso

### Requisitos
- ANTLR
- Java JDK 
- Alias configurados (`antlr4`, `grun`)

### Compilación
# 1. Generar los archivos Java desde la gramática
antlr4 Maclaurin.g4

# 2. Compilar todas las clases generadas
javac Maclaurin*.java

# 3. Ejecucion
grun Maclaurin prog
