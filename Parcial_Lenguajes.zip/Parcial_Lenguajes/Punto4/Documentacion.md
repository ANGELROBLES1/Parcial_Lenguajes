# Algoritmo de Euclides (Recursivo) - C vs Haskell

Este proyecto compara el rendimiento y la robustez del algoritmo de Euclides para calcular el Máximo Común Divisor (MCD) en dos paradigmas: **Imperativo (C)** y **Declarativo/Funcional (Haskell)**.

## Compilación y Ejecución

### En C (Lenguaje Imperativo)
Es fundamental usar el flag `-O3` para habilitar la optimización de recursión de cola.

gcc -O3 euclides.c -o euclides_c
./euclides_c <numero1> <numero2>

C: Eficiencia Cerca del Hardware
Ventaja: Velocidad de ejecución superior debido a la ausencia de un recolector de basura (Garbage Collector) y traducción directa a instrucciones de CPU.

Desventaja: Limitación física por el tamaño de los registros (64 bits). Como se demostró en las pruebas, al superar 9,223,372,036,854,775,807, el programa pierde precisión por desbordamiento (Integer Overflow).

Haskell: Abstracción y Seguridad Matemática
Ventaja: El tipo de dato Integer utiliza memoria dinámica para representar números de cualquier tamaño, permitiendo cálculos astronómicos que el hardware no soporta de forma nativa.

Desventaja: Mayor consumo de recursos iniciales por el entorno de ejecución (runtime) de Haskell.

Conclusiones
La implementación en C es ideal para sistemas donde el rendimiento y el control de memoria son críticos, siempre que los datos se mantengan dentro de los rangos de hardware. Haskell brilla en aplicaciones matemáticas y de alta seguridad, donde la integridad del cálculo y la abstracción del código son más importantes que la velocidad bruta.

## Reporte de Ejecución y Pruebas de Estrés

Para validar la robustez de ambas implementaciones, se ejecutaron los siguientes comandos en la terminal:

### 1. Prueba de Límites (C vs Haskell)
Al ingresar un número que excede los 64 bits ($2^{63}-1$):

# Ejecución en C
./euclides_c 9223372036854775808 1
# Resultado: MCD(9223372036854775807, 1) = 1
# C satura al valor máximo permitido por el sistema.

# Ejecución en Haskell
./euclides_hs 999999999999999999999999999999 3
# Resultado: MCD(999999999999999999999999999999, 3) = 3
# Haskell gestiona el número completo sin pérdida de precisión.

# Ejecución en C
./euclides_c abc 123
# Resultado: "Error: Las entradas deben ser numeros enteros validos."

# Ejecución en Haskell
./euclides_hs 123 xyz
# Resultado: "Error: Las entradas deben ser números enteros."


